<!-- HEADER -->

	<?php include("includes/header.php"); ?>

<!-- HEADER -->

<!-- //w3_agileits_top_nav-->
		<!-- /inner_content-->
				<div class="inner_content">
				    <!-- /inner_content_w3_agile_info-->
					<div class="inner_content_w3_agile_info">
					<!-- /agile_top_w3_grids-->
					   <div class="agile_top_w3_grids">

						   	<div>
								<h3>Welcome, <strong><?php echo $_SESSION['username']; ?>!</strong></h3>
							</div>
					          <ul class="ca-menu">
									<li>
										<a href="#">
											<i class="fa fa-user" aria-hidden="true"></i>
											<div class="ca-content">
												<h4 class="ca-main">1</h4>
												<h3 class="ca-sub">Admins</h3>
											</div>
										</a>
									</li>
									<li>
										<a href="#">
										  <i class="fa fa-users" aria-hidden="true"></i>
											<div class="ca-content">
											<?php
											$query = "SELECT count(*) FROM registrants";
											$registrants = mysqli_query($con, $query);
											$row = mysqli_fetch_row($registrants);
											echo "<h4 class='ca-main one'>$row[0]</h4>";
											?>
												<h3 class="ca-sub one">Registered Attendees</h3>
											</div>
										</a>
									</li>
									<li>
										<a href="#">
											<i class="fa fa-database" aria-hidden="true"></i>
											<div class="ca-content">
											<?php
											$query = "SELECT count(*) FROM registrants where plan='Basic Plan'";
											$registrants = mysqli_query($con, $query);
											$row = mysqli_fetch_row($registrants);
											$total = 10000*$row[0];
											echo "<h4 class='ca-main two'>&#x20a6;$total</h4>";
											?>
												<h3 class="ca-sub two">Basic Plan</h3>
											</div>
										</a>
									</li>
									<li>
										<a href="#">
											<i class="fa fa-tasks" aria-hidden="true"></i>
											<div class="ca-content">
											<?php
											$query = "SELECT count(*) FROM registrants where plan='Premium Plan'";
											$registrants = mysqli_query($con, $query);
											$row = mysqli_fetch_row($registrants);
											$total = 25000*$row[0];
											echo "<h4 class='ca-main three'>&#x20a6;$total</h4>";
											?>
												<h3 class="ca-sub three">Premium Plan</h3>
											</div>
										</a>
									</li>
									<li>
										<a href="#">
											<i class="fa fa-clone" aria-hidden="true"></i>
											<div class="ca-content">
												<h4 class="ca-main four"></h4>
												<h3 class="ca-sub four">New Admin</h3>
											</div>
										</a>
									</li>
									<div class="clearfix"></div>
								</ul>
					   </div>



						
							<div class="prograc-blocks_agileits">
								
								<div class="col-md-12 fallowers_agile agile_info_shadow">
									<h3 class="w3_inner_tittle two">REGISTERED ATTENDEES</h3>
												<div class="work-progres">
													<div class="table-responsive">
														<table class="table table-hover">
														  <thead>
															<tr>
															  <th>#</th>
															  <th>First name</th>
															  <th>Last name</th>                                   
															  <th>Email Address</th>                                   
															  <th>Phone No</th>                                   					
															  <th>Plan</th>
														  </tr>
													  </thead>
													  <tbody>

															<?php

															$query = "SELECT * FROM registrants";
															$select_registrants = mysqli_query($con, $query);

															while($row = mysqli_fetch_assoc($select_registrants)) {
																$id = $row['id'];
																$name = $row['name'];
																$email = $row['email'];
																$phone = $row['phone'];
																$plan_id = $row['plan'];

																echo "
																<tr>
														  <td>$id</td>
														  <td>$name</td>
														  <td>$name</td>                                 
														  <td>$email</td>                                 
														  <td>$phone</td>
														  <td><span class='label label-primary'>$plan_id</span></td>
													  	</tr>
																";}

															?>
													  
												  </tbody>
											  </table>
											</div>
										</div>											
								</div>
									 <div class="clearfix"></div>
							</div>

									    </div>
					<!-- //inner_content_w3_agile_info-->
				</div>
		<!-- //inner_content-->
	</div>
<!-- banner -->
<!--copy rights start here-->
<div class="copyrights">
	 <p>© 2019. All Rights Reserved | Design by  <a href="http://w3layouts.com/" target="_blank">W3layouts</a> </p>
</div>	
<!--copy rights end here-->
<!-- js -->

<script type="text/javascript" src="assets/js/jquery-2.1.4.min.js"></script>
<script src="assets/js/modernizr.custom.js"></script>
<script src="assets/js/classie.js"></script>
<script src="assets/js/gnmenu.js"></script>
<script>
	new gnMenu( document.getElementById( 'gn-menu' ) );
</script>
<script src="assets/js/skycons.js"></script>
<!-- //js -->
<script src="assets/js/screenfull.js"></script>
<script>
	$(function () {
		$('#supported').text('Supported/allowed: ' + !!screenfull.enabled);

		if (!screenfull.enabled) {
			return false;
		}

		$('#toggle').click(function () {
			screenfull.toggle($('#container')[0]);
		});	
	});
</script>
<script src="assets/js/jquery.nicescroll.js"></script>
<script src="assets/js/scripts.js"></script>

<script type="text/javascript" src="assets/js/bootstrap-3.1.1.min.js"></script>


</body>
</html>