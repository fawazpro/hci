<?php

ob_start(); //Turns on output buffering 
session_start();

$timezone = date_default_timezone_set("Africa/Lagos");

$con = mysqli_connect("localhost", "phfoguno_root", "UZe5qdw#1S4H2(", "phfoguno_hci"); //Establish Connection

//Check for errors
if(mysqli_connect_errno()) 
{
	echo "Failed to connect: " . mysqli_connect_errno();
}

?>