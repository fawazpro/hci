<li class="gn-trigger">
        <a class="gn-icon gn-icon-menu"><i class="fa fa-bars" aria-hidden="true"></i><span>Menu</span></a>
        <nav class="gn-menu-wrapper">
            <div class="gn-scroller scrollbar1">
                <ul class="gn-menu agile_menu_drop">
                    <li><a href="dashboard.php"> <i class="fa fa-tachometer"></i> Dashboard</a></li>
                    <li><a href="attendees.php"> <i class="fa fa-users"></i> Registered Attendees</a></li>
                    <li> <a href="profile.php"><i class="fa fa-database"></i> Admin Profile</a> </li>
                    <li> <a href="add-admin.php"><i class="fa fa-user"></i> Add New Admin</a> </li>
                    <li><a href="includes/logout.php"> <i class="fa fa-sign-out"></i> Sign Out</a></li>
                </ul>
            </div><!-- /gn-scroller -->
        </nav>
    </li>