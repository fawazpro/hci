<?php
require 'config/config.php';

if(isset($_SESSION['username'])){
    $userLoggedIn = $_SESSION['username'];
    $user_details_query = mysqli_query($con, "SELECT * FROM admin WHERE username='$userLoggedIn'");
    $user = mysqli_fetch_array($user_details_query);

}else{
    header("Location: index.php");
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
<title>Admin Dashboard</title>
<!-- custom-theme -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Esteem Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //custom-theme -->
<link href="assets/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="assets/css/component.css" rel="stylesheet" type="text/css" media="all" />
<link href="assets/css/export.css" rel="stylesheet" type="text/css" media="all" />
<link href="assets/css/flipclock.css" rel="stylesheet" type="text/css" media="all" />
<link href="assets/css/circles.css" rel="stylesheet" type="text/css" media="all" />
<link href="assets/css/style_grid.css" rel="stylesheet" type="text/css" media="all" />
<link href="assets/css/style.css" rel="stylesheet" type="text/css" media="all" />

<!-- font-awesome-icons -->
<link href="assets/css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome-icons -->
<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800" rel="stylesheet">
</head>
<body>
<!-- banner -->
<div class="wthree_agile_admin_info">
		  <!-- /w3_agileits_top_nav-->
		  <!-- /nav-->
		  <div class="w3_agileits_top_nav">
			<ul id="gn-menu" class="gn-menu-main">
			  		 <!-- /nav_agile_w3l -->

					<!-- SIDEBAR -->

					<?php include("includes/sidebar.php"); ?>

					<!-- SIDEBAR -->


				<li class="second top_bell_nav">
				   <ul class="top_dp_agile ">
						<li class="dropdown head-dpdn">
							<a href="includes/logout.php"><i class="fa fa-sign-out" aria-hidden="true"></i></a>
						</li>
									
					</ul>
				</li>
			

			</ul>
			<!-- //nav -->
			
		</div>
		<div class="clearfix"></div>