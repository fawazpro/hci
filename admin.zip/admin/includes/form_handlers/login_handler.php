<?php

if(isset($_POST['login'])){

    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);//sanitize email for correct format
    $_SESSION['email'] = $email;//store email into session variable

    $password = md5($_POST['password']); //get password

    $check_database_array = mysqli_query($con, "SELECT * FROM admin WHERE email='$email' AND password='$password'");
    $check_login_query = mysqli_num_rows($check_database_array);

    if($check_login_query == 1){
        $row = mysqli_fetch_array($check_database_array);
        $username = $row['username'];
        $firstname = $row['firstname'];
        $lastname = $row['lastname'];

        // set session
        $_SESSION['username'] = $username;
        header("Location: dashboard.php");
        exit();
    }else{
        array_push($error_array, "Email or password was incorrect<br>");
    }
}

?>