<?php

// Declare registration variables
$name = "";
$title = "";
$email = "";
$phone = "";
$plan = "";

if(isset($_POST['register'])) {

    $title = $_POST['title'];
    $name = strip_tags($_POST['name']); //remove html tags
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);//sanitize email for correct format
    $phone = $_POST['phone'];
    $plan = $_POST['plan'];


    $query = "INSERT INTO registrants(title, name, email, phone, plan)";
    $query .= "VALUES('{$title}', '{$name}', '{$email}', '{$phone}', '{$plan}')";

    $register_query = mysqli_query($con, $query);
    // $id = mysqli_insert_id($con);

    if(!$register_query) {
        die("QUERY FAILED" . mysqli_error($con));
    } else {
        echo "<h6 class='alert alert-success'>Registered for Conference successfully!</h6>";
    }

}



?>