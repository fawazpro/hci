<?php
require 'admin/config/config.php';
require 'includes/form_handler/event_register.php';
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <title></title>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <meta name='keywords' content='' />
    <meta name='description' content=''/>
    <meta name='author' content=''/>
    <link rel='shortcut icon' href='icon.png' type='image/png'>
    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <!-- Custom Theme files -->
    <link href="css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
    <link href="css/style.css" type="text/css" rel="stylesheet" media="all">
    <link href="css/menufullpage.css" rel="stylesheet">
    <!-- gallery css -->
    <link href="css/prettyPhoto.css" rel="stylesheet" type="text/css" />
    <!-- font-awesome icons -->
    <link href="css/fontawesome-all.min.css" rel="stylesheet">
    <!-- //Custom Theme files -->
    <!-- online-fonts -->
    <link href="//fonts.googleapis.com/css?family=IBM+Plex+Sans:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i"
        rel="stylesheet">
    <!-- //online-fonts -->
</head>

<body>
    <!-- nav -->
    <a href="#menu" class="menu-link">
        <span>toggle menu</span>
    </a>
    <nav id="menu" class="panel">
        <ul>
            <li>
                <a href="index.html" class="active">Home</a>
            </li>
            <li>
                <a href="#details" class="scroll">Details</a>
            </li>
            <li>
                <a href="#about" class="scroll">About</a>
            </li>
            <li>
                <a href="#registration" class="scroll">Registration fee</a>
            </li>
            <li>
                <a href="#speakers" class="scroll">Speakers</a>
            </li>
            <li>
                <a href="#register" class="scroll">Register</a>
            </li>
        </ul>
    </nav>
    <!-- //nav -->
    <!-- banner -->
    <div class="main position-relative">
        <!-- logo -->
        <h1 class="logo_wthree">
            <a href="index.html">
            </a>
        </h1>
        <!-- //logo -->
        <!-- banner slider -->
        <section class="slide-wrapper">
            <div id="myCarousel" class="carousel  slide" data-ride="carousel" data-interval="10000">
                <!-- Indicators -->
                <ol class="carousel-indicators">
                    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                    <li data-target="#myCarousel" data-slide-to="1"></li>
                    <li data-target="#myCarousel" data-slide-to="2"></li>
                    <li data-target="#myCarousel" data-slide-to="3"></li>
                </ol>
                <!-- Wrapper for slides -->
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <!-- carousel item -->
                        <!-- banner slide -->
                        <div class="agile_banner bg1 text-center">
                            <div class="layer">
                                <div class="container">
                                    <div class="banner_text_wthree">
                                        <h3 data-text="Advancing">Advancing</h3>
                                        <h4 class="my-3">Scientific Frontlines For Sustainable Development</h4>
                                        <ul class="list-inline bnr_list_w3 mt-sm-5 mt-3">
                                            <li class="list-inline-item">
                                                <a class="btn  text-white text-uppercase scroll" href="#about">About </a>
                                            </li>
                                            <li class="list-inline-item">
                                                <a class="btn  text-white text-uppercase bg-dark scroll" href="#pricing">Register</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- //banner slide -->
                    </div>
                    <!-- //carousel item -->
                    <!-- carousel item -->
                    <div class="carousel-item">
                        <!-- banner slide -->
                        <div class="agile_banner bg2 text-center">
                            <div class="layer">
                                <div class="container">
                                    <div class="banner_text_wthree">
                                        <h3 data-text="International">International</h3>
                                        <h4 class="my-3">Conference on Developmental Sciences &amp; Technologies</h4>
                                        <ul class="list-inline bnr_list_w3 mt-sm-5 mt-3">
                                            <li class="list-inline-item">
                                                <a class="btn  text-white text-uppercase scroll" href="#pricing">Register </a>
                                            </li>
                                            <li class="list-inline-item">
                                                <a class="btn  text-white text-uppercase bg-dark scroll" href="#contact">Venue</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- //banner slide -->
                    </div>
                    <!-- //carousel item -->
                </div>
            </div>
        </section>
        <!-- //banner slider -->
    </div>
    <!-- banner -->
    <!-- points -->
    <section class="details" id="details">
        <div class="py-lg-5">
            <div class="container py-5">
                <div class="my-md-5 mt-5">
                    <div class="col-10 mx-auto py-sm-5 pt-4">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="method method--mobile contact_agileinfo1">
                                    <div class="method__icon-con method__icon-con--mobile">
                                        <span class="far fa-building"></span>
                                        <span class="mobile-lines">
                                            <span class="mobile-lines__line mobile-lines__line--small"></span>
                                            <span class="mobile-lines__line mobile-lines__line--big"></span>
                                        </span>
                                    </div>
                                    <!-- contact details grid1-->
                                    <div class="wthree-contact">
                                        <h5 class="py-3">International Conference Center, FUNAAB</h5>
                                        <p></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 my-md-0 my-5 text-center">
                                <div class="method method--fb">
                                    <div class="method__icon-con method__icon-con--fb">
                                        <span class="fas fa-user"></span>
                                        <span class="bubble">
                                            <span class="tail"></span>
                                        </span>
                                    </div>
                                    <!-- fixed social icons -->
                                    <div class="wthree-contact">
                                        <h5 class="py-3">1000+ Participants</h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 text-right">
                                <div class="method method--email">
                                    <div class="method__icon-con method__icon-con--email">
                                        <span class="fas fa-calendar"></span>
                                    </div>
                                    <div class="wthree-contact">
                                        <h5 class="py-3">2-5th July, 2019</h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- //points -->
    <!-- about -->
    <section class="py-5 about-w3sec" id="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 wthree-abtslide">
                    <h2>About Conference</h2>
                </div>
                <div class="col-lg-6 mt-lg-0 mt-4">
                    <h2>Sub-themes for the Conference</h2>
                    <ul type="circle">
                        <li>Policy advancements through science &amp; technology</li>
                        <li>Science &amp; technology in human capital development for the 21st century</li>
                        <li>Food scarcity &amp; safety</li>
                        <li>The role of chemical science in an emerging economy</li>
                        <li>Climate change &amp; environmental sustainability</li>
                        <li>Software systems as an enable for national development</li>
                        <li>Mathematical sciences for national development</li>
                        <li>Adding values for science based education</li>
                        <li>Information technology development</li>
                        <li>Cyber security &amp; national development</li>
                    </ul>
                    <a href="#services" class="btn btn-slide text-white mt-3 scroll">Explore More</a>
                </div>
            </div>
        </div>
    </section>
    <!-- //about -->
    <!-- dates -->
    <section class="py-5 services-w3sec" id="dates">
        <div class="container">
            <div class="agileabt-w3 py-lg-5">
                <div class="w3l-head text-center  py-lg-5">
                    <h4 class="sec-title"> Important Dates</h4>
                </div>
                <div class="clearfix my-md-5 mt-5">
                        <div class="row">
                            <div class="stat-grid col-lg-3 mt-4">
                                <div class="counter py-5 px-3">
                                    <i class="far fa-smile fa-2x"></i>
                                    <div class="my-2"> <b>21st March 2019</b> </div>
                                    <p class="count-text text-capitalize">Paper Submission</p>
                                </div>
                            </div>
                            <div class="stat-grid col-lg-3 mt-4">
                                <div class="counter  py-5 px-3">
                                    <i class=" fab fa-stack-overflow fa-2x"></i>
                                    <div class="my-2"> <b>21st March 2019</b> </div>
                                    <p class="count-text text-capitalize">Paper Review</p>
                                </div>
                            </div>
                            <div class="stat-grid col-lg-3 mt-4">
                                <div class="counter  py-5 px-3">
                                    <i class="fas fa-users fa-2x"></i>
                                    <div class="my-2"> <b>21st March 2019</b> </div>
                                    <p class="count-text text-capitalize">Paper Acceptance</p>
                                </div>
                            </div>
                            <div class="stat-grid col-lg-3 mt-4">
                                <div class="counter  py-5 px-3">
                                    <i class="fas fa-building fa-2x"></i>
                                    <div class="my-2"> <b>21st March 2019</b> </div>
                                    <p class="count-text text-capitalize">Submission Deadline</p>
                                </div>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </section>
    <!-- //dates -->
    <!-- pricing plans -->
    <section class="py-lg-5 py-5 services-w3sec" id="registration">
        <div class="container">
            <div class="agileabt-w3 pt-lg-5">
                <div class="w3l-head text-center  py-lg-5">
                    <h4 class="sec-title">
                        Registration Fee</h4>
                </div>
                <div class="row my-md-5 mt-5">
                    <!-- Table #2s  -->
                    <div class="col-lg-6 col-sm-6 price-wthree">
                        <div class="w3ls-pricing card text-center">
                            <div class="card-header">
                                <h4 class="display-2">
                                    <span class="currency">&#x20A6;</span>10,000
                                    <span class="period">/person</span>
                                </h4>
                            </div>
                            <div class="card-block">
                                <h4 class="card-title price-title">
                                    Regular Plan
                                </h4>
                                <ul class="list-group">
                                    <li class="list-group-item">Ultimate Features</li>
                                    <li class="list-group-item">Responsive Ready</li>
                                </ul>
                                <a href="#" class="btn btn-gradient mt-4">Register</a>
                            </div>
                        </div>
                    </div>
                    <!-- Table #3  -->
                    <div class="col-lg-6 col-sm-6 mx-sm-auto mt-lg-0 mt-5">
                        <div class="w3ls-pricing card text-center">
                            <div class="card-header">
                                <h4 class="display-2">
                                    <span class="currency">&#x20A6;</span>25,000
                                    <span class="period">/person</span>
                                </h4>
                            </div>
                            <div class="card-block">
                                <h4 class="card-title price-title">
                                    Premium Plan
                                </h4>
                                <ul class="list-group">
                                    <li class="list-group-item">Ultimate Features</li>
                                    <li class="list-group-item">Responsive Ready</li>
                                </ul>
                                <a href="#" class="btn btn-gradient mt-4">Register</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- //pricing plans -->
    <!-- speakers -->
    <section class="py-5 services-w3sec" id="speakers">
        <div class="container">
            <div class="agileabt-w3 py-lg-5">
                <div class="w3l-head text-center  py-lg-5">
                    <h4 class="sec-title">Keynote Speakers</h4>
                </div>
                <div class="row my-md-5 mt-5">
                    <div class="col-lg-4 col-md-6">
                        <div class="team-member">
                            <div class="team-img">
                                <img src="images/t1.jpg" alt="team member" class="img-fluid">
                            </div>
                            <div class="team-hover">
                                <div class="desk">
                                    <h4>Prof T. Akinwale</h4>
                                    <p>A professor in Computer Science. Specalizes in AI</p>
                                </div>
                                <div class="s-link">
                                    <a href="#">
                                        <i class="fab fa-facebook-f"></i>
                                    </a>
                                    <a href="#">
                                        <i class="fab fa-twitter"></i>
                                    </a>
                                    <a href="#">
                                        <i class="fab fa-google-plus-g"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="team-title">
                            <h5>Prof A.S. Sodiya</h5>
                            <span>Dept of Computer Science</span>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 my-md-0 my-sm-5 my-3">
                        <div class="team-member">
                            <div class="team-img">
                                <img src="images/t3.jpg" alt="team member" class="img-fluid">
                            </div>
                            <div class="team-hover">
                                <div class="desk">
                                    <h4>Prof A.S. Sodiya</h4>
                                    <p>A professor in Computer Science. Specalizes in Software Engineering</p>
                                </div>
                                <div class="s-link">
                                    <a href="#">
                                        <i class="fab fa-facebook-f"></i>
                                    </a>
                                    <a href="#">
                                        <i class="fab fa-twitter"></i>
                                    </a>
                                    <a href="#">
                                        <i class="fab fa-google-plus-g"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="team-title">
                            <h5>Dr. Alex</h5>
                            <span>Department of Chemistry</span>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 mx-auto my-lg-0 mt-md-5">
                        <div class="team-member">
                            <div class="team-img">
                                <img src="images/t2.jpg" alt="team member" class="img-fluid">
                            </div>
                            <div class="team-hover">
                                <div class="desk">
                                    <h4>Dr. Alex</h4>
                                    <p>A professor in Computer Science. Specalizes in AI</p>
                                </div>
                                <div class="s-link">
                                    <a href="#">
                                        <i class="fab fa-facebook-f"></i>
                                    </a>
                                    <a href="#">
                                        <i class="fab fa-twitter"></i>
                                    </a>
                                    <a href="#">
                                        <i class="fab fa-google-plus-g"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="team-title">
                            <h5>Dr. Adeola</h5>
                            <span>co-founder Alex Inc.</span>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!-- //speakers -->
    <!-- contact -->
    <section class="contact" id="register">
        <div class="py-lg-5">
            <div class="container py-5">
                <div class="my-md-5 mt-5">
                    <!-- contact -->
                    <div class="pt-5 mt-lg-5">
                        <h4 class="sec-title text-center">register for conference</h4>
                        <div class="row mt-lg-5 pt-sm-5 pt-3">
                            <div class="col-lg-10 col-offset-lg-2">


                                <form class="form px-sm-5" action="index.php" method="POST">
                                    <div class="form-group">
                                        <label class="form-label" id="titleLabel" for="title"></label>
                                        <select name="title" id="title" class="form-control">      
                                            <option value="Mr">Mr.</option>
                                            <option value="Mrs">Mrs.</option>
                                            <option value="Dr">Dr.</option>
                                            <option value="Prof">Prof.</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label" id="nameLabel" for="name"></label>
                                        <input type="text" class="form-control" id="name" name="name" placeholder="Your name" tabindex="1" required>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label" id="emailLabel" for="email"></label>
                                        <input type="email" class="form-control" id="email" name="email" placeholder="Your Email" tabindex="2" required>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label" id="phoneLabel" for="phone"></label>
                                        <input type="number" class="form-control" id="phone" name="phone" placeholder="Your Phone Number" tabindex="2" required>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label" id="planLabel" for="plan"></label>
                                        <select name="plan" id="plan" class="form-control">
                                        <?php
                                            $query = "SELECT * FROM plans";
                                            $select_plans = mysqli_query($con, $query);

                                            // confirmQuery($select_categories);

                                            while($row = mysqli_fetch_assoc($select_plans)) {
                                                $plan_id = $row['id'];
                                                $name = $row['name'];
                                                $price = $row['price'];

                                                echo "<option value='$name'>&#x20a6;{$price}</option>";
                                            }

                                            
                                        ?>
                                        </select>
                                    </div>
                                    <div class="text-center mt-5">
                                        <button type="submit" name="register" class="btn btn-border btn-lg w-100">Register</button>
                                    </div>
                                </form>
                                <!-- End form -->
                            </div>
                            <!-- <div class="col-lg-4 map mt-lg-0 mt-5">
                                <iframe class="p-2" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3023.9503398796587!2d-73.9940307!3d40.719109700000004!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25a27e2f24131%3A0x64ffc98d24069f02!2sCANADA!5e0!3m2!1sen!2sin!4v1441710758555"
                                    allowfullscreen></iframe>
                            </div> -->
                            <!-- End col -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- //contact -->
    <!-- Footer -->
    <footer id="footer" class="py-5">
        <div class="container">
            <div class="row  py-lg-5">
                <div class="col-lg-4 col-sm-6 footer_grid1">
                    <h5>Location</h5>
                    <div class="d-flex">
                        <span class="far fa-building mr-2"></span>
                        <p>International Conference Center,
                            <br>FUNAAB Ogun State.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6 mt-sm-0 mt-5">
                    <h5>Quick links</h5>
                    <ul class="list-unstyled quick-links">
                        <li>
                            <a href="#">
                                <i class="fa fa-angle-double-right"></i>Home</a>
                        </li>
                        <li>
                            <a href="#about" class="scroll">
                                <i class="fa fa-angle-double-right"></i>About</a>
                        </li>
                        <li>
                            <a href="#details" class="scroll">
                                <i class="fa fa-angle-double-right"></i>Details</a>
                        </li>
                        <li>
                            <a href="#registration" class="scroll">
                                <i class="fa fa-angle-double-right"></i>Registration plans</a>
                        </li>
                        <li>
                            <a href="#speakers" class="scroll">
                                <i class="fa fa-angle-double-right"></i>Speakers</a>
                        </li>
                    </ul>
                </div>


                <div class="col-lg-4 col-sm-6 mt-lg-0 mt-5">
                    <h5>subscribe to newsletter</h5>
                    <form action="#" method="post">
                        <div class="form-group">
                            <input type="email" class="form-control  bg-dark border-0 border-rounded text-white" id="emailid" placeholder="Enter email"
                                name="email" required>
                        </div>
                        <div class="form-group">
                            <input type="Submit" class="form-control bg-light text-dark border-0 border-rounded" id="sub" value="Submit" name="sub">
                        </div>
                    </form>
                </div>
            </div>
            <hr>
            <div class="cpy-right text-center pt-4">
                <p class="text-white">© 2019. All rights reserved | Design by
                    <a href="http://w3layouts.com"> W3layouts.</a>
                </p>
            </div>
        </div>
    </footer>
    <!-- /Footer -->
    <!-- js -->
    <script src="js/jquery-2.2.3.min.js"></script>
    <!-- //js -->
    <!-- navigation -->
    <script src="js/menuFullpage.min.js"></script>
    <!-- testimonials -->
    <link href="css/owl.carousel.css" rel="stylesheet">
    <script src="js/owl.carousel.js"></script>
    <script>
        $(document).ready(function () {
            $("#owl-demo").owlCarousel({
                items: 1,
                lazyLoad: true,
                autoPlay: false,
                navigation: true,
                navigationText: true,
                pagination: true,
            });
        });
    </script>
    <!-- //for testimonials slider -->
    <script src="js/expert.js"></script>
    <!-- contact validation js -->
    <script src="js/form-validation.js"></script>
    <!-- jQuery-Photo-filter-lightbox-Gallery-plugin -->
    <script src="js/move-top.js "></script>
    <script src="js/easing.js "></script>
    <script src="js/SmoothScroll.min.js "></script>
    <script src="js/jquery-1.7.2.js"></script>
    <script src="js/jquery.quicksand.js"></script>
    <script src="js/script.js"></script>
    <!-- //jQuery-Photo-filter-lightbox-Gallery-plugin -->


    <!-- Bootstrap core JavaScript
================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/bootstrap.js"></script>
</body>

</html>